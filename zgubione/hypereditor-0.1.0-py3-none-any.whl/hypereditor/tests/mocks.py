TEXT_BLOCK = {
    "type": "text",
    "children": [],
    "settings": {
        "text": "Sample Text"
    },
    "id": "i1554530213_4",
    "general": {
        "padding": {
            "unit": "px",
            "left": None,
            "top": None,
            "right": None,
            "bottom": None
        },
        "margin": {
            "unit": "px",
            "left": None,
            "top": None,
            "right": None,
            "bottom": None
        }
    }
}