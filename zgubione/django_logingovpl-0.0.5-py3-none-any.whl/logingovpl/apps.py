from django.apps import AppConfig


class LogingovplConfig(AppConfig):
    name = 'logingovpl'
